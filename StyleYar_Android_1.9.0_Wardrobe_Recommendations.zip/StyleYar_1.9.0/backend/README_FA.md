# Backend استایل‌یار

## اجرا
1. فایل `.env.example` را به `.env` کپی کنید.
2. `OPENAI_API_KEY` را فقط روی سرور قرار دهید.
3. اجرا: `docker compose up --build`
4. سلامت: `http://localhost:8000/health`

## AI
نسخه فعلی از Responses API برای تحلیل تصویر لباس استفاده می‌کند. مدل پیش‌فرض `gpt-5.6-luna` است و کلید API هرگز نباید داخل APK قرار گیرد.

## فروشگاه
- `POST /api/shops` ثبت فروشگاه
- `POST /api/products` ثبت محصول
- `GET /api/products` فهرست محصولات
- `GET /go/{product_id}` ثبت کلیک و هدایت به فروشگاه

در محیط واقعی، قبل از انتشار باید احراز هویت فروشنده، امضای لینک، webhook سفارش و تسویه کمیسیون اضافه شود.
