from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pydantic_settings import BaseSettings
from pathlib import Path
from uuid import uuid4
from datetime import datetime, timezone
import base64, json, sqlite3, os

class Settings(BaseSettings):
    host: str = "0.0.0.0"
    port: int = 8000
    ai_provider: str = "mock"
    openai_api_key: str = ""
    openai_model: str = "gpt-5.6-luna"
    app_base_url: str = "http://10.0.2.2:8000"
    allowed_origins: str = "http://localhost:3000,http://10.0.2.2:8000"
    max_upload_mb: int = 8
    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
UPLOADS = DATA / "uploads"
DATA.mkdir(exist_ok=True); UPLOADS.mkdir(exist_ok=True)
DB = DATA / "styleyar.db"

app = FastAPI(title="StyleYar API", version="1.9.0")
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.allowed_origins.split(",") if x.strip()], allow_methods=["GET","POST","PUT","DELETE","OPTIONS"], allow_headers=["*"])

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS garments(id TEXT PRIMARY KEY,user_id TEXT,image_url TEXT,category TEXT,color TEXT,style TEXT,season TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS shops(id TEXT PRIMARY KEY,name TEXT,base_url TEXT,commission_rate REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,shop_id TEXT,name TEXT,price INTEGER,image_url TEXT,category TEXT,color TEXT,product_url TEXT,stock INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS clicks(id TEXT PRIMARY KEY,user_id TEXT,product_id TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY,user_id TEXT,outfit_id TEXT,liked INTEGER,reason TEXT,created_at TEXT);
    '''); c.commit();
    shops=[("shop-a","فروشگاه نمونه A","https://example.com",8.0),("shop-b","فروشگاه نمونه B","https://example.org",6.0)]
    for s in shops: c.execute("INSERT OR IGNORE INTO shops VALUES (?,?,?,?)",s)
    products=[("p1","shop-a","کتانی سفید روزمره",1890000,"","کفش","سفید","https://example.com/product/white-sneaker",1),("p2","shop-b","شلوار کرم مینیمال",1290000,"","شلوار","کرم","https://example.org/product/beige-pants",1),("p3","shop-a","پیراهن سفید ساده",990000,"","پیراهن","سفید","https://example.com/product/white-shirt",1)]
    for p in products: c.execute("INSERT OR IGNORE INTO products VALUES (?,?,?,?,?,?,?,?,?)",p)
    c.commit(); c.close()
init_db()

class Feedback(BaseModel):
    user_id: str="demo"
    outfit_id: str
    liked: bool
    reason: str|None=None

class StyleRequest(BaseModel):
    user_id: str="demo"
    occasion: str="روزمره"
    style: str="مینیمال"

@app.get("/health")
def health(): return {"ok":True,"version":"1.9.0"}

@app.post("/api/garments/analyze")
async def analyze_garment(file: UploadFile=File(...), user_id: str="demo"):
    raw=await file.read()
    if not raw: raise HTTPException(400,"تصویر خالی است")
    if len(raw) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"حجم تصویر نباید بیشتر از {settings.max_upload_mb} مگابایت باشد")
    ext=(file.filename or "image.jpg").split(".")[-1].lower(); ext=ext if ext in {"jpg","jpeg","png","webp"} else "jpg"
    gid=str(uuid4()); path=UPLOADS/f"{gid}.{ext}"; path.write_bytes(raw)
    result=await vision_analyze(raw, file.content_type or "image/jpeg")
    c=db(); c.execute("INSERT INTO garments VALUES (?,?,?,?,?,?,?,?)",(gid,user_id,f"/media/uploads/{path.name}",result["category"],result["color"],result["style"],result["season"],datetime.now(timezone.utc).isoformat())); c.commit(); c.close()
    return {"id":gid,"image_url":f"/media/uploads/{path.name}",**result}

async def vision_analyze(raw:bytes, mime:str):
    if settings.ai_provider.lower()=="openai" and settings.openai_api_key:
        try:
            from openai import OpenAI
            client=OpenAI(api_key=settings.openai_api_key)
            data="data:"+mime+";base64,"+base64.b64encode(raw).decode()
            prompt='''این تصویر یک لباس است. فقط JSON معتبر برگردان با کلیدهای category,color,style,season. category یکی از: پیراهن، تیشرت، شلوار، کت، کفش، لباس بیرونی، اکسسوری، لباس دیگر. season می‌تواند بهار، تابستان، پاییز، زمستان، چهارفصل باشد. فارسی بنویس.'''
            r=client.responses.create(model=settings.openai_model,input=[{"role":"user","content":[{"type":"input_text","text":prompt},{"type":"input_image","image_url":data}]}])
            txt=r.output_text.strip().replace("```json","").replace("```","")
            return json.loads(txt)
        except Exception:
            pass
    return {"category":"تیشرت","color":"مشکی","style":"کژوال","season":"چهارفصل"}

@app.get("/api/garments")
def garments(user_id:str="demo"):
    c=db(); rows=c.execute("SELECT * FROM garments WHERE user_id=? ORDER BY created_at DESC",(user_id,)).fetchall(); c.close(); return [dict(r) for r in rows]

@app.post("/api/outfits/generate")
def generate(req:StyleRequest):
    """Build up to three outfit ideas using only this user's saved garments."""
    c=db()
    rows=c.execute("SELECT * FROM garments WHERE user_id=? ORDER BY created_at DESC LIMIT 100",(req.user_id,)).fetchall()
    feedback_rows=c.execute("SELECT outfit_id, liked, reason FROM feedback WHERE user_id=? ORDER BY created_at DESC LIMIT 100",(req.user_id,)).fetchall()
    c.close()
    items=[dict(r) for r in rows]
    if not items:
        return {"occasion":req.occasion,"style":req.style,"outfits":[],"reason":"برای پیشنهاد واقعی، ابتدا چند لباس به کمدت اضافه کن."}

    def group_for(item):
        cat=(item.get("category") or "").strip().lower()
        if any(k in cat for k in ("کفش", "بوت", "کتانی", "صندل")) or "shoe" in cat: return "shoes"
        if any(k in cat for k in ("شلوار", "دامن", "جین", "لباس پایین")) or "pants" in cat: return "bottoms"
        if any(k in cat for k in ("کت", "کاپشن", "مانتو", "لباس بیرونی", "پالتو")): return "outerwear"
        if any(k in cat for k in ("پیراهن", "تیشرت", "تی‌شرت", "بلوز", "تاپ", "پلیور", "هودی", "لباس")): return "tops"
        return "other"

    groups={k:[] for k in ("tops","bottoms","shoes","outerwear","other")}
    for item in items: groups[group_for(item)].append(item)
    # The three options rotate through real garments, never invented fallback items.
    outfits=[]
    for i in range(3):
        chosen=[]
        for key in ("tops","bottoms","outerwear","shoes","other"):
            arr=groups[key]
            if arr:
                candidate=arr[i % len(arr)]
                if candidate not in chosen: chosen.append(candidate)
        if not chosen:
            chosen=[items[i % len(items)]]
        colors=[(x.get("color") or "").strip() for x in chosen if x.get("color")]
        neutral={"سفید","مشکی","طوسی","خاکستری","کرم","بژ","سرمه‌ای","قهوه‌ای"}
        color_score=90 if len(set(colors)) <= 1 or all(c in neutral for c in colors) else 82
        outfits.append({
            "outfit_id":str(uuid4()),
            "name":["ترکیب متعادل","ترکیب دوم","ترکیب سوم"][i],
            "items":chosen,
            "color_score":color_score,
            "style_score":85 if req.style else 80,
            "reason":f"این پیشنهاد برای «{req.occasion}» و سبک «{req.style}» از لباس‌های ثبت‌شده در کمد تو ساخته شده است."
        })
    return {"occasion":req.occasion,"style":req.style,"outfits":outfits,"wardrobe_count":len(items),"reason":"پیشنهادها بر اساس لباس‌های واقعی ذخیره‌شده در کمد ساخته شده‌اند."}

@app.post("/api/feedback")
def feedback(f:Feedback):
    c=db(); c.execute("INSERT INTO feedback VALUES (?,?,?,?,?,?)",(str(uuid4()),f.user_id,f.outfit_id,int(f.liked),f.reason,datetime.now(timezone.utc).isoformat())); c.commit(); c.close(); return {"ok":True}

@app.get("/api/products")
def products(category:str|None=None, color:str|None=None, limit:int=20):
    q="SELECT p.*,s.name shop_name FROM products p JOIN shops s ON s.id=p.shop_id WHERE p.stock=1"; args=[]
    if category: q+=" AND p.category=?"; args.append(category)
    if color: q+=" AND p.color=?"; args.append(color)
    q+=" LIMIT ?"; args.append(limit)
    c=db(); rows=c.execute(q,args).fetchall(); c.close(); return [dict(r) for r in rows]


class ShopCreate(BaseModel):
    name: str
    base_url: str
    commission_rate: float = 0

class ProductCreate(BaseModel):
    shop_id: str
    name: str
    price: int
    image_url: str = ""
    category: str = "لباس"
    color: str = ""
    product_url: str
    stock: bool = True

@app.post("/api/shops")
def create_shop(x: ShopCreate):
    sid=str(uuid4()); c=db(); c.execute("INSERT INTO shops VALUES (?,?,?,?)",(sid,x.name,x.base_url,x.commission_rate)); c.commit(); c.close(); return {"id":sid,"name":x.name}

@app.post("/api/products")
def create_product(x: ProductCreate):
    pid=str(uuid4()); c=db(); c.execute("INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?)",(pid,x.shop_id,x.name,x.price,x.image_url,x.category,x.color,x.product_url,int(x.stock))); c.commit(); c.close(); return {"id":pid,"name":x.name}

@app.get("/api/shops")
def shops():
    c=db(); rows=c.execute("SELECT id,name,base_url,commission_rate FROM shops").fetchall(); c.close(); return [dict(r) for r in rows]

@app.get("/go/{product_id}")
def go(product_id:str,user_id:str="demo"):
    c=db(); p=c.execute("SELECT * FROM products WHERE id=?",(product_id,)).fetchone()
    if not p: raise HTTPException(404,"محصول پیدا نشد")
    c.execute("INSERT INTO clicks VALUES (?,?,?,?)",(str(uuid4()),user_id,product_id,datetime.now(timezone.utc).isoformat())); c.commit(); c.close()
    from fastapi.responses import RedirectResponse
    return RedirectResponse(p["product_url"],status_code=307)

from fastapi.staticfiles import StaticFiles
app.mount("/media", StaticFiles(directory=DATA), name="media")
